const container = document.getElementById('floating-container');
const colors = ['#FF5ECF','#FFD966','#A75CFF','#F7A8FF','#FF9EDB','#FFDA99'];

// 12個の浮遊丸
const circles = [];
for(let i=0;i<12;i++){
  const div = document.createElement('div');
  div.className = 'floating-circle';
  const size = 40 + Math.random()*40;
  div.style.width = div.style.height = size + 'px';
  div.style.background = colors[Math.floor(Math.random()*colors.length)];
  div.style.top = Math.random()*(window.innerHeight-80) + 'px';
  div.style.left = Math.random()*(window.innerWidth-80) + 'px';
  div.style.opacity = 0.7;
  div.style.zIndex = 0;
  container.appendChild(div);
  circles.push({
    el: div,
    x: parseFloat(div.style.left),
    y: parseFloat(div.style.top),
    size: size,
    baseSize: size,
    scaleDir: 1,
    speed: 0.2 + Math.random()*0.5,
    velocityY: 0
  });
}

// スクロール状態
let scrolling = false;
let scrollTimer;
window.addEventListener('scroll', () => {
  scrolling = true;
  clearTimeout(scrollTimer);
  scrollTimer = setTimeout(()=> scrolling=false, 100);
});

// ハート生成
document.body.addEventListener('click', e=>{
  const heart = document.createElement('div');
  heart.className = 'heart';
  heart.style.left = e.clientX + 'px';
  heart.style.top = e.clientY + 'px';
  heart.style.color = colors[Math.floor(Math.random()*colors.length)];
  heart.textContent = '❤️';
  document.body.appendChild(heart);
  setTimeout(()=>heart.remove(),2000);
});

// アニメーション
function animate(){
  circles.forEach(c=>{
    if(!scrolling){
      c.size += 0.2*c.scaleDir;
      if(c.size > c.baseSize*1.2 || c.size < c.baseSize*0.8) c.scaleDir *= -1;
      c.el.style.transform = `translate(${c.x}px, ${c.y}px) scale(${c.size/c.baseSize})`;
    } else {
      c.velocityY += -c.speed*0.1;
      c.velocityY *= 0.9;
      c.y += c.velocityY;
      if(c.y < -100) c.y = window.innerHeight + 100;
      if(c.y > window.innerHeight+100) c.y = -100;
      c.el.style.transform = `translate(${c.x}px, ${c.y}px) scale(${c.size/c.baseSize})`;
    }
  });
  requestAnimationFrame(animate);
}
animate();
